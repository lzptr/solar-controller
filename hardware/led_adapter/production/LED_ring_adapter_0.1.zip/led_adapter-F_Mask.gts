G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-10-22T23:26:39+02:00*
G04 #@! TF.ProjectId,led_adapter,6c65645f-6164-4617-9074-65722e6b6963,0.1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-10-22 23:26:39*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.038000X-2.125000X0.550000X-2.125000X-0.550000X2.125000X-0.550000X2.125000X0.550000X0*%
%ADD11C,2.976000*%
%ADD12C,2.076000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X-3425000Y-2000000D03*
X1825000Y-2000000D03*
X-3425000Y0D03*
X1825000Y0D03*
X-3425000Y2000000D03*
X1825000Y2000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J2*
X-9600000Y0D03*
X9600000Y0D03*
D12*
X-2540000Y4570000D03*
X2540000Y4570000D03*
X5330000Y0D03*
X2540000Y-4570000D03*
X-2540000Y-4570000D03*
G04 #@! TD*
M02*
